﻿using ArakCLI;

namespace TestProject1
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void Novekvo()
        {
            var termek = new Arak("10001\tteszt\t1000\t1100");
            int eredmeny = termek.Valtozas();
            Assert.AreEqual(100, eredmeny);
        }
        [TestMethod]
        public void Csokkeno()
        {
            var termek = new Arak("10001\tteszt\t1100\t1000");
            int eredmeny = termek.Valtozas();
            Assert.AreEqual(-100, eredmeny);
        }
        [TestMethod]
        public void Stabil()
        {
            var termek = new Arak("10001\tteszt\t1000\t1000");
            int eredmeny = termek.Valtozas();
            Assert.AreEqual(0, eredmeny);
        }
    }
}
