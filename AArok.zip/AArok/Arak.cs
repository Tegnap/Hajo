﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArakCLI
{
    public class Arak
    {
        public Arak(int december, int januar, string kod, string megnevezes)
        {
            December = december;
            Januar = januar;
            Kod = kod;
            Megnevezes = megnevezes;
        }

        public string Kod { get; private set; }
        public string Megnevezes { get; private set; }
        public int Januar { get; private set; }
        public int December { get; private set; }
       
       


        public Arak(string sor)
        {
            string[] adatok = sor.Split('\t');
            string[] adatok2 = adatok[1].Split(',');
            Kod = adatok[0];
            Megnevezes = adatok2[0];
            Januar = int.Parse(adatok[2]);
            December = int.Parse(adatok[3]);
        }
        public int Valtozas()
        {
            return (December - Januar);
        }
    }
}
