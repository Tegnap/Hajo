﻿using ArakCLI;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ArakWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Arak> Wpflista = new List<Arak>();
        public MainWindow()
        {
            InitializeComponent();
      
        }

        private void dgArak_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgArak.SelectedItem is Arak kivalasztott)
            {
                lblTermek.Content = kivalasztott.Megnevezes;
                pbValtozas.Value = kivalasztott.Valtozas();

            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (dgArak.SelectedItem is Arak kivalaszott)
            {
                Program.lista.Remove(kivalaszott);
                dgArak.Items.Refresh();
                lblTermek.Content = "Termek";
                pbValtozas.Value = 0;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter("Termekek.txt"))
                {
                    
                    foreach (var item in Program.lista)
                    {
                        sw.WriteLine($"{item.Megnevezes} ==> {(item.Valtozas()<= 0 ? "": "+")}{item.Valtozas()}");
                    }
                    MessageBox.Show("Sikeres mentés");
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Program.Beolvas();
            
            dgArak.ItemsSource = Program.lista;
        }
    }
}