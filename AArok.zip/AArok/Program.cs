﻿namespace ArakCLI
{
    public class Program
    {
        public static List<Arak> lista = new List<Arak>();
        static void Main(string[] args)
        {
            Beolvas();
            Console.WriteLine("1. feladat:");
            Console.WriteLine($"Az állományban {lista.Count()} db termék található.");
            Feladat3();
            Feladat5();
            Feladat6();
        }

        private static void Feladat6()
        {
            List<Arak> csokken = new List<Arak>();
            List<int> csokkenAr = new List<int>();
            foreach(var item  in lista)
            {
                if ((item.Januar - item.December) > 0)
                {
                    int ar = item.Januar - item.December;
                    csokken.Add(item);
                    csokkenAr.Add(ar);
                }
            }
            StreamWriter sw = new StreamWriter("olcsobb.txt");
            int count = 0;
            foreach (var item in csokken)
            {
                
                sw.WriteLine($"{item.Kod};{item.Megnevezes};{csokkenAr[count]}");
                count ++;
            }
            sw.Close();
        }

        private static void Feladat5()
        {
            int max = 0;
            string maxitem = "";
            foreach (var item in lista)
            {
                int aktualis = item.Valtozas();
                if ( aktualis > max)
                {
                    max = aktualis;
                    maxitem = item.Megnevezes;
                }
                
            }
            Console.WriteLine($"A legnagyobb mértékben a {maxitem} emelkedett, {max} Ft-tal.");
        }

        private static void Feladat3()
        {
            Console.WriteLine("3. feladat:");
            Console.Write("Kérem adja meg a termék kódját! ");
            string termekKodja = Console.ReadLine();
            bool talal = false;
            foreach (var item in lista)
            {
                if (termekKodja == item.Kod)
                {
                    double atlag = (item.Januar + item.December) / 2.0;
                    Console.WriteLine($"Termék neve: {item.Megnevezes}, átlagára 2024-ben: {atlag} Ft");
                    talal = true;
                    break;
                }
                
            }
            if (talal == false)
            {
                Console.WriteLine("Nincs ilyen termék a listában :(");
            }

        }

        public static void Beolvas()
        {
            string[] sorok = File.ReadAllLines("Arak2024.txt").Skip(1).ToArray();
            foreach (var item in sorok)
            {
                lista.Add(new Arak(item));
            }
        }
    }
}
