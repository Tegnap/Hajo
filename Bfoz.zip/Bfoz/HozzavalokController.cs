﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ReceptAPI.Models;

namespace ReceptAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HozzavalokController : ControllerBase
    {

        [HttpGet("All")]
        public IActionResult Getall()
        {
            try
            {
                using (var context = new ReceptdbContext())
                {
                    var hozzavalo = context.Hozzavalos.ToList();
                    return StatusCode(200, hozzavalo);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(400, $"Hiba volt te buzi: {ex.Message}");
            }
        }

        [HttpPost("Uj")]
        public async Task<IActionResult> Uj(Hozzavalo hozzavalo)
        {
            try
            {
                using (var context = new ReceptdbContext())
                {
                    await context.AddAsync(hozzavalo);
                    await context.SaveChangesAsync();
                    return StatusCode(201, "siker");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(400, $"Hiba volt te buzi: {ex.Message}");
            }
        }

    }
}


//public class HozzavaloesController : ControllerBase
//{
//    private readonly ReceptdbContext _context;

//    public HozzavaloesController(ReceptdbContext context)
//    {
//        _context = context;
//    }

//    // GET: api/Hozzavaloes
//    [HttpGet]
//    public async Task<ActionResult<IEnumerable<Hozzavalo>>> GetHozzavalos()
//    {
//        return await _context.Hozzavalos.ToListAsync();
//    }

//    // GET: api/Hozzavaloes/5
//    [HttpGet("{id}")]
//    public async Task<ActionResult<Hozzavalo>> GetHozzavalo(int id)
//    {
//        var hozzavalo = await _context.Hozzavalos.FindAsync(id);

//        if (hozzavalo == null)
//        {
//            return NotFound();
//        }

//        return hozzavalo;
//    }

//    // PUT: api/Hozzavaloes/5
//    // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//    [HttpPut("{id}")]
//    public async Task<IActionResult> PutHozzavalo(int id, Hozzavalo hozzavalo)
//    {
//        if (id != hozzavalo.Id)
//        {
//            return BadRequest();
//        }

//        _context.Entry(hozzavalo).State = EntityState.Modified;

//        try
//        {
//            await _context.SaveChangesAsync();
//        }
//        catch (DbUpdateConcurrencyException)
//        {
//            if (!HozzavaloExists(id))
//            {
//                return NotFound();
//            }
//            else
//            {
//                throw;
//            }
//        }

//        return NoContent();
//    }

//    // POST: api/Hozzavaloes
//    // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//    [HttpPost]
//    public async Task<ActionResult<Hozzavalo>> PostHozzavalo(Hozzavalo hozzavalo)
//    {
//        _context.Hozzavalos.Add(hozzavalo);
//        await _context.SaveChangesAsync();

//        return CreatedAtAction("GetHozzavalo", new { id = hozzavalo.Id }, hozzavalo);
//    }

//    // DELETE: api/Hozzavaloes/5
//    [HttpDelete("{id}")]
//    public async Task<IActionResult> DeleteHozzavalo(int id)
//    {
//        var hozzavalo = await _context.Hozzavalos.FindAsync(id);
//        if (hozzavalo == null)
//        {
//            return NotFound();
//        }

//        _context.Hozzavalos.Remove(hozzavalo);
//        await _context.SaveChangesAsync();

//        return NoContent();
//    }

//    private bool HozzavaloExists(int id)
//    {
//        return _context.Hozzavalos.Any(e => e.Id == id);
//    }
//}
