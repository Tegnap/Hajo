﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ReceptAPI.DTO;
using ReceptAPI.Models;

namespace ReceptAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReceptController : ControllerBase
    {


        [HttpGet("{id}")]
        public IActionResult Getbyid(int id)
        {
            try
            {
                using (var context = new ReceptdbContext())
                {
                    var list = context.Recepts.Include(s => s.Szakacs).Include(n => n.Nehezseg).Where(x => x.Id == id).Select(d => new HozzavaloDTO()
                    {
                        Cookneve = d.Szakacs.Nev,
                        Szint = d.Nehezseg.Szint,
                        ElkeszitesiTime = d.ElkeszitesiIdo,
                        ReceptNeve = d.Nev,

                    }).FirstOrDefault();
                    if (list == null)
                    {
                       return StatusCode(404, "NIcnsne ilyen id");
                    }
                    return StatusCode(200, list);
                }
            }



            catch (Exception ex)
            {
                return StatusCode(400, $"Hiba volt te buzi: {ex.Message}");
            }
        }
    }
}
