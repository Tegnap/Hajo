﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ReceptAPI.Models;

namespace ReceptAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SzakacsController : ControllerBase
    {

        [HttpPut("Modosit")]
        public async Task<IActionResult> Uj(Szakac szakac)
        {
            try
            {
                using (var context = new ReceptdbContext())
                {
                    if (context.Szakacs.Any(s => s.Id == szakac.Id))
                    {
                        context.Update(szakac);
                        await context.SaveChangesAsync();
                        return StatusCode(201, "siker");
                    }
                    else
                    {
                        return StatusCode(404, "nicsnenen");
                    }
                    
                }
            }
            catch (Exception ex)
            {
                return StatusCode(400, $"Hiba volt te buzi: {ex.Message}");
            }
        }

        [HttpDelete("Torles{id}")]
        public async Task<IActionResult> Delet(int id)
        {
            try
            {
                using (var context = new ReceptdbContext())
                {
                    var keresett = context.Szakacs.FirstOrDefault(s => s.Id == id);
                    if (context.Szakacs.Any(s => s.Id == id))
                    {
                        context.Remove(new Szakac() { Id = id });
                        await context.SaveChangesAsync();
                        return StatusCode(201, "siker");
                    }
                    else
                    {
                        return StatusCode(404, "nicsnenen");
                    }

                }
            }
            catch (Exception ex)
            {
                return StatusCode(400, $"Hiba volt te buzi: {ex.Message}");
            }
        }
    }
}
