﻿using HalakAPI.DTOs;
using HalakAPI.Models;
using Microsoft.AspNetCore.Mvc;

namespace HalakAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class HalakController : Controller
    {
        [HttpGet("Fajmeret")]
        public IActionResult Fajmeret()
        {
            try
            {
                using (var context = new HalakContext())
                {
                    var list = context.Halaks.Select(x => new HalDTO
                    {
                        HalFajta = x.Faj,
                        HalMerete = x.MeretCm,
                        ToNev = x.To != null ? x.To.Nev : null


                    })
                    .ToList();
                    return StatusCode(200, list);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(400, ex.Message);
            }
        }

        [HttpPost]
        public IActionResult Create([FromBody] Halak hal)
        {
            try
            {
                using (var context = new HalakContext())
                {
                    if (hal == null)
                    {
                        return StatusCode(400, "Üres objektum nem rögzíthető!");
                    }
                    context.Halaks.Add(hal);
                    context.SaveChanges();
                    return StatusCode(200, "Sikeres rögzítés.");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(400, ex.Message);
            }
        }

        [HttpPut]
        public async Task<IActionResult> Modosit([FromBody] Halak hal)
        {
            try
            {
                using (var context = new HalakContext())
                {
                    var regi = context.Halaks.FirstOrDefault(x => x.Id == hal.Id);
                    if (regi == null)
                        return StatusCode(404, "Nincs ilyen azonosítójú hal!");

                    regi.Nev = hal.Nev;
                    regi.Faj = hal.Faj;
                    regi.MeretCm = hal.MeretCm;
                    regi.ToId = hal.ToId;
                    regi.Kep = hal.Kep;
                    await context.SaveChangesAsync();
                    return StatusCode(200, "Sikeres módosítás.");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(400, ex.Message);
            }
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> Delet(int id)
        {
            try
            {
                using (var context = new HalakContext())
                {
                    var hal = context.Halaks.FirstOrDefault(x=> x.Id == id);
                    if (hal == null)
                    {
                        return StatusCode(404, "Nincs ilyen azonosítójú hal");
                    }
                    context.Halaks.Remove(hal);
                    await context.SaveChangesAsync();
                    return StatusCode(200, "Sikeres törlés");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(400, ex.Message);
            }
        }
        [HttpDelete("NIcsnenasy{id}")]
        public IActionResult Delete(int id) 
        {
            try
            {
                using (var context = new HalakContext())
                {
                    var delhal = context.Halaks.FirstOrDefault(x=> x.Id==id);
                    if (delhal == null) {
                        return StatusCode(404, "rossz id");
                            }

                    context.Halaks.Remove(delhal);
                    context.SaveChanges();
                    return StatusCode(200, "Sikeres törlés");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(400, ex.Message);
            }
        }

    }
}
