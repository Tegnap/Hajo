﻿using HalakAPI.Models;
using Microsoft.AspNetCore.Mvc;

namespace HalakAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class HorgaszokController : Controller
    {
        [HttpGet("All")]
        public IActionResult GetAll()
        {
            try
            {
                using (var context = new HalakContext())
                {
                    var horgszok = context.Horgaszoks.ToList();
                    return StatusCode(200, horgszok);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(400, ex.Message);
                
            }
        }

        [HttpGet("ById{id}")]
        public IActionResult GetById(int id)
        {
            try
            {
                using (var context = new HalakContext())
                {
                    var horgaszokbyid = context.Halaks.FirstOrDefault(x => x.Id == id);
                     if(horgaszokbyid == null)
                    {
                        return StatusCode(404, "Nincs ilyen azonosítójú horgász!");
                    }
                     return StatusCode(200, horgaszokbyid);

                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
